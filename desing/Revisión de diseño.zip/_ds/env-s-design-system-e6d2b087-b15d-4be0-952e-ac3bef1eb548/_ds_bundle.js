/* @ds-bundle: {"format":3,"namespace":"EnvSDesignSystem_e6d2b0","components":[{"name":"MonogramaEnves","sourcePath":"components/brand/MonogramaEnves.jsx"},{"name":"OrnamentoSection","sourcePath":"components/brand/OrnamentoSection.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"ButtonLink","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Heading","sourcePath":"components/core/Heading.jsx"}],"sourceHashes":{"components/brand/MonogramaEnves.jsx":"dbd44fedaa82","components/brand/OrnamentoSection.jsx":"c2a21d3a6226","components/core/Button.jsx":"76b55eb23ce8","components/core/Eyebrow.jsx":"29a2c2b60343","components/core/Heading.jsx":"f92d5ac7e776","ui_kits/espejo/app.jsx":"7955c4ee5751","ui_kits/website/app.jsx":"9a064d9974e5"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.EnvSDesignSystem_e6d2b0 = window.EnvSDesignSystem_e6d2b0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/MonogramaEnves.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * MonogramaEnves — el wordmark E-n-V-é-s con asignación cromática por letra:
 *   E,s → estructura / lo visible   n → cocoa claro (lo oculto)
 *   V → cocoa medio (la rendija)    é → oro champagne (el acento iniciático)
 * Tipografía: Marcellus (romana lapidaria) vía --font-wordmark.
 * variant 'light' pone E/s en marfil (fondos oscuros); 'dark' en tinta (fondos claros).
 */
function MonogramaEnves({
  variant = 'dark',
  fontSize = 220,
  ariaLabel = 'Envés',
  style,
  ...props
}) {
  const eAndS = variant === 'light' ? '#F4EADE' : '#0F0F0F';
  return /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: "0 0 600 400",
    xmlns: "http://www.w3.org/2000/svg",
    role: "img",
    "aria-label": ariaLabel,
    style: style
  }, props), /*#__PURE__*/React.createElement("text", {
    x: "300",
    y: "265",
    textAnchor: "middle",
    fontFamily: "var(--font-wordmark, 'Marcellus', 'Trajan Pro', Georgia, serif)",
    fontWeight: 400,
    fontSize: fontSize,
    letterSpacing: fontSize * 0.015
  }, /*#__PURE__*/React.createElement("tspan", {
    fill: eAndS
  }, "E"), /*#__PURE__*/React.createElement("tspan", {
    fill: "#8B6F5A"
  }, "n"), /*#__PURE__*/React.createElement("tspan", {
    fill: "#5C3D2E"
  }, "V"), /*#__PURE__*/React.createElement("tspan", {
    fill: "#C4A265"
  }, "\xE9"), /*#__PURE__*/React.createElement("tspan", {
    fill: eAndS
  }, "s")));
}
Object.assign(__ds_scope, { MonogramaEnves });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/MonogramaEnves.jsx", error: String((e && e.message) || e) }); }

// components/brand/OrnamentoSection.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * OrnamentoSection — separador decorativo entre secciones. Línea + figura
 * geométrica central + línea, estilo art déco austero 1920s. 4 variantes.
 */
function OrnamentoSection({
  variant = 'rombo',
  width = 80,
  color = 'var(--oro-champagne, #C4A265)',
  style,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      justifyContent: 'center',
      padding: '60px 0',
      ...style
    },
    "aria-hidden": "true"
  }, props), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 80 24",
    width: width,
    height: width * 24 / 80,
    xmlns: "http://www.w3.org/2000/svg"
  }, /*#__PURE__*/React.createElement("g", {
    stroke: color,
    strokeWidth: "1",
    fill: "none"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "0",
    y1: "12",
    x2: "22",
    y2: "12"
  }), variant === 'rombo' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("polygon", {
    points: "40,4 46,12 40,20 34,12",
    fill: color,
    opacity: "0.5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "40",
    cy: "12",
    r: "2",
    fill: color
  })), variant === 'circulo' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M 30 12 L 36 6 L 42 12 L 36 18 Z",
    fill: color,
    opacity: "0.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "50",
    cy: "12",
    r: "3"
  })), variant === 'estrella' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
    x1: "28",
    y1: "6",
    x2: "34",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "34",
    y1: "6",
    x2: "28",
    y2: "18"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "40",
    cy: "12",
    r: "2",
    fill: color
  }), /*#__PURE__*/React.createElement("line", {
    x1: "46",
    y1: "6",
    x2: "52",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "52",
    y1: "6",
    x2: "46",
    y2: "18"
  })), variant === 'puntos' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "32",
    cy: "12",
    r: "2",
    fill: color
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "40",
    cy: "12",
    r: "2.5",
    fill: color
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "48",
    cy: "12",
    r: "2",
    fill: color
  })), /*#__PURE__*/React.createElement("line", {
    x1: "58",
    y1: "12",
    x2: "80",
    y2: "12"
  }))));
}
Object.assign(__ds_scope, { OrnamentoSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/OrnamentoSection.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * Button / ButtonLink — botón editorial de Envés.
 * Esquinas rectas, label Familjen Grotesk uppercase con tracking, y barra de oro
 * que entra en hover mientras el texto pasa a negro. Variantes: primary (relleno),
 * outline (filete), ghost (sin borde).
 */
const base = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '10px',
  fontFamily: "var(--font-label, 'Familjen Grotesk', sans-serif)",
  fontSize: '0.72rem',
  fontWeight: 500,
  letterSpacing: '0.22em',
  textTransform: 'uppercase',
  borderRadius: 0,
  cursor: 'pointer',
  textDecoration: 'none',
  transition: 'background-color .4s cubic-bezier(.25,.46,.45,.94), color .4s, border-color .4s',
  boxSizing: 'border-box'
};
const sizes = {
  md: {
    padding: '13px 28px'
  },
  lg: {
    padding: '16px 36px'
  }
};
function styleFor(variant, hover) {
  if (variant === 'outline') {
    return {
      background: hover ? 'rgba(196,162,101,0.12)' : 'transparent',
      color: 'var(--negro-tinta, #0F0F0F)',
      border: `1px solid ${hover ? 'var(--oro-champagne, #C4A265)' : 'rgba(15,15,15,0.4)'}`
    };
  }
  if (variant === 'ghost') {
    return {
      background: hover ? 'rgba(196,162,101,0.12)' : 'transparent',
      color: 'var(--negro-tinta, #0F0F0F)',
      border: '1px solid transparent'
    };
  }
  // primary
  return {
    background: hover ? 'var(--oro-champagne, #C4A265)' : 'var(--negro-tinta, #0F0F0F)',
    color: hover ? 'var(--negro-tinta, #0F0F0F)' : 'var(--crema-marfil, #F4EADE)',
    border: `1px solid ${hover ? 'var(--oro-champagne, #C4A265)' : 'var(--negro-tinta, #0F0F0F)'}`
  };
}
function Button({
  children,
  variant = 'primary',
  size = 'md',
  style,
  ...props
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...sizes[size],
      ...styleFor(variant, hover),
      ...style
    }
  }, props), children);
}
function ButtonLink({
  children,
  variant = 'primary',
  size = 'md',
  href = '#',
  style,
  ...props
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...sizes[size],
      ...styleFor(variant, hover),
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { Button, ButtonLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Eyebrow — etiqueta superior de sección. Familjen Grotesk uppercase con tracking
 * extremo y, opcionalmente, un filete de oro a la izquierda (estilo hero).
 */
function Eyebrow({
  children,
  withTick = true,
  onDark = false,
  style,
  ...props
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '16px',
      fontFamily: "var(--font-label, 'Familjen Grotesk', sans-serif)",
      fontSize: '0.78rem',
      fontWeight: 500,
      letterSpacing: '0.32em',
      textTransform: 'uppercase',
      color: onDark ? 'var(--crema-marfil, #F4EADE)' : 'var(--cocoa-medio, #5C3D2E)',
      ...style
    }
  }, props), withTick && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '32px',
      height: '1px',
      background: 'var(--oro-champagne, #C4A265)',
      flex: 'none'
    }
  }), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Heading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Heading — título editorial en Cormorant Garamond. Soporta nivel (1–3) y
 * el patrón de énfasis italic dorado: pasa texto entre asteriscos *así* y se
 * renderiza en EB Garamond italic con color de acento.
 *
 *   level 1 → headline hero (clamp 2.75→4.75rem), em = oro champagne
 *   level 2 → sección (clamp 2→3.5rem), em = cocoa profundo
 *   level 3 → card (1.5rem)
 */
const levelStyle = {
  1: {
    fontSize: 'clamp(2.75rem, 5.6vw, 4.75rem)',
    lineHeight: 1.02,
    letterSpacing: '-0.012em',
    fontWeight: 400,
    emColor: 'var(--oro-champagne, #C4A265)'
  },
  2: {
    fontSize: 'clamp(2rem, 4.4vw, 3.5rem)',
    lineHeight: 1.1,
    letterSpacing: '-0.01em',
    fontWeight: 400,
    emColor: 'var(--cocoa-profundo, #3D2817)'
  },
  3: {
    fontSize: '1.5rem',
    lineHeight: 1.25,
    letterSpacing: '-0.005em',
    fontWeight: 500,
    emColor: 'var(--cocoa-profundo, #3D2817)'
  }
};
function renderEmphasis(children, emColor) {
  if (typeof children !== 'string') return children;
  const parts = children.split(/(\*[^*]+\*)/g);
  return parts.map((p, i) => {
    if (p.startsWith('*') && p.endsWith('*') && p.length > 2) {
      return /*#__PURE__*/React.createElement("em", {
        key: i,
        style: {
          fontFamily: "var(--font-italic, 'EB Garamond', serif)",
          fontStyle: 'italic',
          fontWeight: 400,
          color: emColor
        }
      }, p.slice(1, -1));
    }
    return p;
  });
}
function Heading({
  children,
  level = 2,
  onDark = false,
  style,
  ...props
}) {
  const L = levelStyle[level] || levelStyle[2];
  const Tag = `h${level}`;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      fontFamily: "var(--font-display, 'Cormorant Garamond', serif)",
      fontWeight: L.fontWeight,
      fontSize: L.fontSize,
      lineHeight: L.lineHeight,
      letterSpacing: L.letterSpacing,
      color: onDark ? 'var(--crema-marfil, #F4EADE)' : 'var(--negro-tinta, #0F0F0F)',
      margin: 0,
      textWrap: 'pretty',
      ...style
    }
  }, props), renderEmphasis(children, L.emColor));
}
Object.assign(__ds_scope, { Heading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Heading.jsx", error: String((e && e.message) || e) }); }

// ui_kits/espejo/app.jsx
try { (() => {
// Envés — UI Kit: Espejo de Precisión (chatbot de diagnóstico)
// Recreación fiel de ChatEspejo.tsx + recursos.css. Flujo: gate (nombre+email) → chat.
// Respuestas del bot simuladas (canned) — el original llama a /api/espejo (Anthropic).

const {
  useState,
  useRef,
  useEffect
} = React;
function FlorDeLaVida() {
  return /*#__PURE__*/React.createElement("svg", {
    className: "flor",
    width: "620",
    height: "620",
    viewBox: "-350 -350 700 700",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("g", {
    fill: "none",
    stroke: "#C4A265",
    strokeWidth: "0.6"
  }, /*#__PURE__*/React.createElement("circle", {
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "120",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "-120",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "60",
    cy: "104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "-60",
    cy: "104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "60",
    cy: "-104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "-60",
    cy: "-104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    r: "240",
    strokeWidth: "0.4"
  })));
}

// Respuestas simuladas en el registro de la marca (sobrio, confrontativo, sin wellness)
const BOT_REPLIES = ['Lo que describes no es un problema de información. Es un patrón. Dime: ¿cuántas veces has *visto* esto con claridad y aun así no lo has movido?', 'Nombras la situación con precisión — eso ya descarta la confusión. Entonces la pregunta no es **qué** hacer, sino **qué evitas** al no hacerlo. ¿Qué se sostendría intacto si no cambias nada?', 'Hay una coherencia que tu cuerpo conoce antes que tu discurso. Cuando piensas en dar el paso, ¿dónde lo sientes — y qué se tensa?', 'Esto es suficiente para empezar. Te envío el diagnóstico cruzado de las cinco dimensiones a tu correo. No es un veredicto: es un punto de partida que ya sabías pero no habías nombrado.'];
function Gate({
  onEnter
}) {
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const ok = nombre.trim() && /\S+@\S+\.\S+/.test(email);
  return /*#__PURE__*/React.createElement("div", {
    className: "gate"
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, "Herramienta gratuita"), /*#__PURE__*/React.createElement("h1", null, "Espejo de ", /*#__PURE__*/React.createElement("em", null, "Precisi\xF3n")), /*#__PURE__*/React.createElement("p", null, "Antes de dar un paso, mira d\xF3nde est\xE1s parado. Describe tu situaci\xF3n; el sistema cruza las cinco dimensiones y hace el resto."), /*#__PURE__*/React.createElement("input", {
    value: nombre,
    onChange: e => setNombre(e.target.value),
    placeholder: "Tu nombre"
  }), /*#__PURE__*/React.createElement("input", {
    type: "email",
    value: email,
    onChange: e => setEmail(e.target.value),
    placeholder: "tu@correo.com"
  }), /*#__PURE__*/React.createElement("button", {
    disabled: !ok,
    onClick: () => ok && onEnter({
      nombre,
      email
    }),
    style: {
      opacity: ok ? 1 : 0.5
    }
  }, "Iniciar el Espejo"), /*#__PURE__*/React.createElement("p", {
    className: "legal"
  }, "Espejo editorial. No constituye evaluaci\xF3n cl\xEDnica ni sustituye atenci\xF3n profesional."));
}
function Markdown({
  text
}) {
  // mini-markdown: **bold** y *italic*
  const html = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
  return /*#__PURE__*/React.createElement("p", {
    dangerouslySetInnerHTML: {
      __html: html
    }
  });
}
function Chat({
  user
}) {
  const [mensajes, setMensajes] = useState([]);
  const [input, setInput] = useState('');
  const [cargando, setCargando] = useState(false);
  const [turno, setTurno] = useState(0);
  const [cerrada, setCerrada] = useState(false);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [mensajes, cargando]);
  function enviar() {
    const texto = input.trim();
    if (!texto || cargando || cerrada) return;
    setInput('');
    const next = [...mensajes, {
      rol: 'user',
      contenido: texto
    }];
    setMensajes(next);
    setCargando(true);
    setTimeout(() => {
      const reply = BOT_REPLIES[Math.min(turno, BOT_REPLIES.length - 1)];
      setMensajes([...next, {
        rol: 'assistant',
        contenido: reply
      }]);
      setCargando(false);
      const t = turno + 1;
      setTurno(t);
      if (t >= BOT_REPLIES.length) setCerrada(true);
      inputRef.current?.focus();
    }, 1400);
  }
  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      enviar();
    }
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "chat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chat-header"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "chat-title"
  }, "Espejo de Precisi\xF3n"), /*#__PURE__*/React.createElement("span", {
    className: "chat-subtitle"
  }, cerrada ? 'Sesión concluida' : `Hola, ${user.nombre}. Describe tu situación. El sistema hace el resto.`)), /*#__PURE__*/React.createElement("div", {
    className: "chat-messages",
    ref: scrollRef
  }, mensajes.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "bienvenida"
  }, "Describe una situaci\xF3n concreta en la que sientes que algo no cierra: una decisi\xF3n que pospones, una din\xE1mica que se repite, algo que sabes pero no mueves."), mensajes.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `msg ${m.rol === 'user' ? 'msg-user' : 'msg-bot'}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "msg-content"
  }, m.rol === 'assistant' ? /*#__PURE__*/React.createElement(Markdown, {
    text: m.contenido
  }) : m.contenido.split('\n').map((l, j) => /*#__PURE__*/React.createElement("p", {
    key: j
  }, l))))), cargando && /*#__PURE__*/React.createElement("div", {
    className: "msg msg-bot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "typing"
  }, /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null))), cerrada && /*#__PURE__*/React.createElement("div", {
    className: "msg msg-bot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "msg-content"
  }, /*#__PURE__*/React.createElement(Markdown, {
    text: `Te enviamos el diagnóstico a **${user.email}**. Revisa también spam. *Esta sesión ha concluido.*`
  })))), !cerrada ? /*#__PURE__*/React.createElement("div", {
    className: "chat-input-area"
  }, /*#__PURE__*/React.createElement("textarea", {
    ref: inputRef,
    className: "chat-input",
    rows: 2,
    value: input,
    onChange: e => setInput(e.target.value),
    onKeyDown: onKey,
    placeholder: "Describe tu situaci\xF3n\u2026",
    disabled: cargando
  }), /*#__PURE__*/React.createElement("button", {
    className: "chat-send",
    onClick: enviar,
    disabled: cargando || !input.trim(),
    "aria-label": "Enviar"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"
  })))) : null, /*#__PURE__*/React.createElement("p", {
    className: "chat-disclaimer"
  }, "Este Espejo de Precisi\xF3n tiene prop\xF3sito educativo. No constituye evaluaci\xF3n cl\xEDnica ni sustituye atenci\xF3n profesional."));
}
function App() {
  const [user, setUser] = useState(null);
  return /*#__PURE__*/React.createElement("div", {
    className: "espejo-stage"
  }, /*#__PURE__*/React.createElement(FlorDeLaVida, null), user ? /*#__PURE__*/React.createElement(Chat, {
    user: user
  }) : /*#__PURE__*/React.createElement(Gate, {
    onEnter: setUser
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/espejo/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/app.jsx
try { (() => {
// Envés — UI Kit: enves.io homepage
// Recreación fiel del home real (src/app/page.tsx + home.css + enves-shell.css).
// Usa componentes del bundle: Button, ButtonLink, Eyebrow, Heading, MonogramaEnves, OrnamentoSection.

const {
  useState,
  useEffect
} = React;
const DS = window.EnvSDesignSystem_e6d2b0;
const {
  Button,
  ButtonLink,
  Eyebrow,
  Heading,
  MonogramaEnves,
  OrnamentoSection
} = DS;

// ── Motivos de fondo (de FlorDeLaVida / PolvoDorado) ──
function FlorDeLaVida({
  opacity = 0.18,
  size = 700
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "-350 -350 700 700",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%,-50%)',
      opacity,
      pointerEvents: 'none',
      animation: 'enves-rot 120s linear infinite'
    }
  }, /*#__PURE__*/React.createElement("g", {
    fill: "none",
    stroke: "#C4A265",
    strokeWidth: "0.6"
  }, /*#__PURE__*/React.createElement("circle", {
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "120",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "-120",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "60",
    cy: "104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "-60",
    cy: "104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "60",
    cy: "-104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "-60",
    cy: "-104",
    r: "120"
  }), /*#__PURE__*/React.createElement("circle", {
    r: "240",
    strokeWidth: "0.4"
  })));
}
const DUST = [[2, '12%', '8%', 9, 0], [1.5, '22%', '18%', 11, 1], [2.5, '35%', '12%', 8, 2], [1.5, '65%', '6%', 13, 0.5], [2, '78%', '14%', 10, 3], [1, '18%', '38%', 12, 1.5], [2, '42%', '32%', 9, 2.5], [1.5, '88%', '28%', 11, 0], [2.5, '25%', '58%', 14, 1], [1.5, '55%', '68%', 8, 2], [2, '75%', '75%', 12, 0.5], [1, '15%', '82%', 10, 3], [2.5, '40%', '88%', 13, 1.5], [1.5, '68%', '92%', 9, 2.5], [2, '85%', '60%', 11, 0]];
function PolvoDorado() {
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none'
    }
  }, DUST.map(([s, top, left, dur, delay], i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      position: 'absolute',
      width: s,
      height: s,
      top,
      left,
      borderRadius: '50%',
      background: '#C4A265',
      animation: `enves-float ${dur}s ${delay}s infinite ease-in-out`
    }
  })));
}

// ── Header fijo ──
function Header({
  theme,
  onToggle
}) {
  const links = ['Manifiesto', 'Protocolo', 'Recursos', 'Blog'];
  return /*#__PURE__*/React.createElement("header", {
    className: "kit-header"
  }, /*#__PURE__*/React.createElement("a", {
    className: "kit-logo",
    href: "#top",
    "aria-label": "Env\xE9s \u2014 Inicio"
  }, /*#__PURE__*/React.createElement(MonogramaEnves, {
    variant: theme === 'dark' ? 'light' : 'dark',
    style: {
      height: 38,
      width: 'auto'
    }
  })), /*#__PURE__*/React.createElement("nav", {
    className: "kit-nav"
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    className: "kit-nav-link"
  }, l)), /*#__PURE__*/React.createElement("a", {
    href: "#espejo",
    className: "kit-nav-cta"
  }, "Espejo"), /*#__PURE__*/React.createElement("button", {
    className: "kit-theme",
    onClick: onToggle,
    "aria-label": "Cambiar tema"
  }, theme === 'dark' ? '☾' : '✦')));
}

// ── Hero ──
function Hero() {
  return /*#__PURE__*/React.createElement("div", {
    className: "kit-hero",
    id: "top"
  }, /*#__PURE__*/React.createElement(FlorDeLaVida, {
    opacity: 0.22
  }), /*#__PURE__*/React.createElement(PolvoDorado, null), /*#__PURE__*/React.createElement("section", {
    className: "kit-hero-content"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kit-hero-grid"
  }, /*#__PURE__*/React.createElement(MonogramaEnves, {
    variant: "light",
    className: "kit-mono-massive",
    ariaLabel: "Env\xE9s"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    onDark: true,
    style: {
      marginBottom: 36,
      letterSpacing: '0.45em'
    }
  }, "Pensamiento aplicado a la vida real"), /*#__PURE__*/React.createElement("h1", {
    className: "kit-hero-h1"
  }, "El rev\xE9s de las cosas no es misterio.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", null, "Es lo que sostiene la fachada.")), /*#__PURE__*/React.createElement("p", {
    className: "kit-hero-sub"
  }, "Un protocolo para personas con recorrido. No es coaching, no es terapia, no es wellness. Es una cartograf\xEDa precisa para quienes ya saben demasiado y a\xFAn no han ido hasta el fondo."), /*#__PURE__*/React.createElement("div", {
    className: "kit-hero-actions"
  }, /*#__PURE__*/React.createElement(ButtonLink, {
    variant: "outline",
    size: "lg",
    style: {
      color: 'var(--crema-marfil)',
      borderColor: '#C4A265'
    }
  }, "Leer el Manifiesto"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "kit-link-arrow"
  }, "Ver el recorrido completo \u2192"))))));
}

// ── Bloque de dos columnas ──
function TwoCol({
  id,
  eyebrow,
  headline,
  sub,
  children,
  dark
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: `kit-section ${dark ? 'kit-section-dark' : ''}`,
    id: id
  }, /*#__PURE__*/React.createElement("div", {
    className: "kit-wrap"
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    onDark: dark
  }, eyebrow), /*#__PURE__*/React.createElement(Heading, {
    level: 2,
    onDark: dark,
    style: {
      margin: '18px 0 0',
      maxWidth: 720
    }
  }, headline), sub && /*#__PURE__*/React.createElement("p", {
    className: `kit-sub ${dark ? 'on-dark' : ''}`
  }, sub), /*#__PURE__*/React.createElement("div", {
    className: "kit-cols"
  }, children)));
}
function List({
  items,
  variant
}) {
  return /*#__PURE__*/React.createElement("ul", {
    className: `kit-list ${variant === 'no' ? 'kit-list-no' : ''}`
  }, items.map((it, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    dangerouslySetInnerHTML: {
      __html: it
    }
  })));
}
function App() {
  const [theme, setTheme] = useState('light');
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);
  return /*#__PURE__*/React.createElement("div", {
    className: "enves-page"
  }, /*#__PURE__*/React.createElement(Header, {
    theme: theme,
    onToggle: () => setTheme(t => t === 'dark' ? 'light' : 'dark')
  }), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(TwoCol, {
    id: "posicionamiento",
    eyebrow: "Posicionamiento",
    headline: "Lo que *no* encontrar\xE1s aqu\xED"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Heading, {
    level: 3,
    style: {
      marginBottom: 16
    }
  }, "Sin coaching. Sin terapia. Sin wellness de consumo."), /*#__PURE__*/React.createElement(List, {
    items: ['No somos un espacio de coaching.', 'No ofrecemos terapia ni acompañamiento emocional.', 'No vendemos bienestar como producto.', 'No trabajamos con frases motivacionales ni promesas de cambio rápido.']
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Heading, {
    level: 3,
    style: {
      marginBottom: 16
    }
  }, "Donde el conocimiento deja de ser refugio."), /*#__PURE__*/React.createElement("p", {
    className: "kit-sub",
    style: {
      marginTop: 0
    }
  }, "Trabajamos en el punto donde el conocimiento deja de ser ", /*#__PURE__*/React.createElement("strong", null, "refugio"), " y empieza a ser ", /*#__PURE__*/React.createElement("strong", null, "responsabilidad"), "."))), /*#__PURE__*/React.createElement(OrnamentoSection, {
    variant: "rombo"
  }), /*#__PURE__*/React.createElement(TwoCol, {
    id: "dimensiones",
    eyebrow: "El trabajo",
    headline: "Un protocolo de *soberan\xEDa personal*",
    sub: /*#__PURE__*/React.createElement(React.Fragment, null, "Env\xE9s opera donde la mayor\xEDa de los enfoques evitan ir: el lugar donde el autoenga\xF1o sofisticado se sostiene precisamente porque parece inteligente.")
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Heading, {
    level: 3,
    style: {
      marginBottom: 16
    }
  }, "Biol\xF3gica \xB7 Mental \xB7 Emocional"), /*#__PURE__*/React.createElement(List, {
    items: ['<strong>Biológica —</strong> Lo que comes, respiras y decides con tu cuerpo habla de tu nivel de criterio.', '<strong>Mental —</strong> Las creencias no son errores. Son arquitectura.', '<strong>Emocional —</strong> Lo que el ego evita no desaparece. Se convierte en síntoma.']
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Heading, {
    level: 3,
    style: {
      marginBottom: 16
    }
  }, "F\xEDsica \xB7 Ps\xEDquica"), /*#__PURE__*/React.createElement(List, {
    items: ['<strong>Física —</strong> La coherencia entre lo que dices y lo que tu cuerpo expresa no se finge. Se encarna.', '<strong>Psíquica —</strong> El miedo profundo, la pulsión, la vergüenza. Ahí es donde operamos.']
  }))), /*#__PURE__*/React.createElement("section", {
    className: "kit-section kit-section-cream"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kit-wrap kit-narrow"
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Origen"), /*#__PURE__*/React.createElement(Heading, {
    level: 2,
    style: {
      margin: '18px 0 0'
    }
  }, "Por qu\xE9 existe este *espacio*"), /*#__PURE__*/React.createElement("p", {
    className: "kit-sub"
  }, "Env\xE9s no naci\xF3 de un m\xE9todo ni de un retiro. Naci\xF3 del contacto directo con lo que la transformaci\xF3n personal contempor\xE1nea sistem\xE1ticamente evita: el miedo profundo, la verg\xFCenza, la incoherencia entre el discurso elevado y la vida real."), /*#__PURE__*/React.createElement(ButtonLink, {
    variant: "outline",
    size: "lg",
    style: {
      marginTop: 8
    }
  }, "Conocer la historia completa"))), /*#__PURE__*/React.createElement(TwoCol, {
    id: "para-quien",
    eyebrow: "Filtro",
    headline: "Para qui\xE9n es este *trabajo*"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Heading, {
    level: 3,
    style: {
      marginBottom: 16
    }
  }, "Esto es para ti si:"), /*#__PURE__*/React.createElement(List, {
    items: ['Ya recorriste caminos de desarrollo personal y sentiste que algo faltaba', 'Tienes la sospecha de que tu sofisticación también es tu prisión', 'No buscas más información — buscas una metodología que te confronte', 'Estás dispuesto a perder comodidad a cambio de coherencia']
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Heading, {
    level: 3,
    style: {
      marginBottom: 16
    }
  }, "Esto NO es para ti si:"), /*#__PURE__*/React.createElement(List, {
    variant: "no",
    items: ['Buscas soluciones rápidas o recetas de bienestar', 'Necesitas que te digan que todo está bien', 'No estás dispuesto a cuestionar tus propias estructuras', 'Prefieres acumular conocimiento antes que actuar']
  }))), /*#__PURE__*/React.createElement("section", {
    className: "kit-section kit-section-dark kit-espejo",
    id: "espejo"
  }, /*#__PURE__*/React.createElement(FlorDeLaVida, {
    opacity: 0.1,
    size: 520
  }), /*#__PURE__*/React.createElement("div", {
    className: "kit-wrap kit-narrow",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    onDark: true
  }, "Herramienta gratuita"), /*#__PURE__*/React.createElement(Heading, {
    level: 2,
    onDark: true,
    style: {
      margin: '18px 0 0'
    }
  }, "Donde est\xE1s *hoy*"), /*#__PURE__*/React.createElement("p", {
    className: "kit-sub on-dark"
  }, "No te va a decir lo que quieres escuchar. Te va a mostrar lo que ya sabes pero no has nombrado. El Espejo cruza las cinco dimensiones: biol\xF3gica, mental, emocional, f\xEDsica y ps\xEDquica."), /*#__PURE__*/React.createElement("div", {
    className: "kit-hero-actions"
  }, /*#__PURE__*/React.createElement(ButtonLink, {
    variant: "outline",
    size: "lg",
    style: {
      color: 'var(--crema-marfil)',
      borderColor: '#C4A265'
    }
  }, "Iniciar el Espejo de Precisi\xF3n")), /*#__PURE__*/React.createElement("p", {
    className: "kit-disclaimer"
  }, "Espejo editorial. No constituye evaluaci\xF3n cl\xEDnica ni sustituye atenci\xF3n profesional.")))), /*#__PURE__*/React.createElement("footer", {
    className: "kit-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kit-footer-inner"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "kit-footer-legal"
  }, "El contenido de enves.io tiene car\xE1cter informativo y editorial. No constituye consejo m\xE9dico, psicol\xF3gico ni terap\xE9utico profesional."), /*#__PURE__*/React.createElement("p", {
    className: "kit-footer-copy"
  }, "\xA9 2026 Env\xE9s \xB7 Pensamiento aplicado a la vida real")), /*#__PURE__*/React.createElement("nav", {
    className: "kit-footer-links"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Aviso Legal"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Condiciones"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Privacidad")))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/app.jsx", error: String((e && e.message) || e) }); }

__ds_ns.MonogramaEnves = __ds_scope.MonogramaEnves;

__ds_ns.OrnamentoSection = __ds_scope.OrnamentoSection;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.ButtonLink = __ds_scope.ButtonLink;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Heading = __ds_scope.Heading;

})();
