# Envés — Design System

> **Envés** — proyecto editorial y formativo de alta gama en el cruce de pensamiento crítico, trabajo somático y soberanía personal. **No es coaching, terapia ni wellness.** Estética *dark academia* editorial sobre negro, con un único acento en oro champagne. Registro sobrio, iniciático, misterioso — deliberadamente anti-wellness y anti-coaching.
>
> *"El revés de lo que parece."*

Este design system permite a agentes de diseño crear interfaces y materiales con la marca Envés: producción real o prototipos desechables.

---

## Fuentes (sources)

Construido leyendo el código fuente real del producto:

- **Repositorio GitHub:** [`rioroi11/enves.io`](https://github.com/rioroi11/enves.io) — app Next.js 16 (React 19, Tailwind 4, Supabase, Resend). El sistema visual vive en `src/app/enves-palette.css` (source of truth), `enves-brand-variables.css`, `globals.css`, `home.css`, `enves-shell.css`, y los componentes de `src/components/brand/`. Explóralo para profundizar.
- **Assets de marca:** `public/brand/` del repo (isotipo, wordmarks, lockups) — copiados a `assets/`.

> Para reconstruir o ampliar este sistema, vale la pena leer el repo directamente: el archivo `public/brand/README.md` documenta el concepto del isotipo, y `src/app/enves-palette.css` lleva notas de diseño sobre cada decisión.

### Productos representados
1. **enves.io** — web principal: manifiesto, posicionamiento, las 5 dimensiones, recursos. → `ui_kits/website/`
2. **Espejo de Precisión** — chatbot de diagnóstico que cruza 5 dimensiones (biológica, mental, emocional, física, psíquica). → `ui_kits/espejo/`
3. **Escalera de umbrales** (Umbral I/II → Protocolo) — recreada como UI kit: aplica el isotipo (figura que se abre, watermark, sello de cierre) y el set de tres glifos como navegación de la escalera. → `ui_kits/escalera/`
4. *akademia.enves.io* — existe en el repo como ruta; no recreada aún como UI kit.

---

## CONTENT FUNDAMENTALS — cómo se escribe

El tono es **sobrio, iniciático, confrontativo**. Editorial, no comercial. Nunca motivacional.

- **Registro:** culto y directo. Frases cortas y declarativas alternadas con una sentencia editorial larga. Mucho punto y aparte. El silencio (espacio negativo) es parte del mensaje.
- **Persona:** habla en **primera persona del plural institucional** ("Trabajamos en el punto donde…", "No ofrecemos terapia") y se dirige al lector de **"tú"** ("Si llegaste hasta aquí sin cerrar la página, algo en ti ya decidió"). La marca **firma siempre como "Envés"**, nunca con nombre de persona.
- **Definición por negación:** la marca se define por lo que NO es. *"Sin coaching. Sin terapia. Sin wellness de consumo."* Listas de "Esto es para ti si… / Esto NO es para ti si…".
- **Léxico recurrente:** *criterio, soberanía, fachada, el revés, la rendija, el envés, umbral, autoengaño sofisticado, coherencia, encarnar, responsabilidad.*
- **Casing:** títulos en Cormorant con minúscula natural (no Title Case). Labels/eyebrows en MAYÚSCULA con tracking extremo. El nombre se escribe **EnVés** (mayúscula/minúscula deliberada; en color por letra cuando es wordmark).
- **Énfasis:** italic editorial (EB Garamond) para la palabra cargada de sentido, casi siempre en oro o cocoa. En cuerpo, `<strong>` lleva subrayado fino de oro.
- **Emoji:** **nunca.** No hay emoji en ninguna superficie. Los únicos "iconos" textuales son la flecha `→` (listas afirmativas) y la `×` (listas de exclusión).
- **Disclaimers:** presentes y sobrios — la marca aclara que no es servicio de salud mental ("No constituye evaluación clínica ni sustituye atención profesional").

**Ejemplos reales:**
- Headline: *"El revés de las cosas no es misterio. Es lo que sostiene la fachada."*
- Sub: *"Un protocolo para quienes ya saben demasiado y aún no han ido hasta el fondo."*
- CTA-cierre: *"No ofrecemos inscripción abierta… No todas las solicitudes son admitidas."*

---

## VISUAL FOUNDATIONS

**Estética:** dark academia editorial + un único metal (oro champagne). Geometría sagrada austera, art déco de los años 20, esoterismo sobrio. Anti-wellness: nada de degradados pastel, nada de redondeces blandas, nada de ilustración alegre.

- **Color:** paleta cerrada de negros cosmos/tinta, cocoa (profundo/medio/claro), oro (champagne/claro/oscuro) y cremas (marfil/papel). El **oro es el único acento con voz** y se reserva a lo más cargado de sentido (la *é*, filetes, CTAs). Sin verdes, sin sage, sin rosa, sin azul medianoche, sin burgundy. Dark mode invierte fondos y textos pero **mantiene el oro** para que el sistema simbólico siga reconocible. Ver `tokens/colors.css`.
- **Tipografía:** cuatro familias de texto (todas Google Fonts — son las reales del producto): **Cormorant Garamond** (display, romanos masivos), **EB Garamond italic** (citas y énfasis), **Familjen Grotesk** (labels uppercase, tracking 0.22–0.45em), **Inter** (cuerpo, 18px/1.7), más **Marcellus** (romana lapidaria) reservada al **nombre / wordmark EnVés** vía `--font-wordmark`. Headlines fluidos con `clamp()`, tracking negativo (−0.012em), italic dorado para el énfasis.
- **Fondos:** negro cosmos plano para hero/footer/secciones profundas; crema marfil para secciones intermedias; papel cálido base. Hero con **radial-gradient** cosmos→papel. Capa global de **ruido de papel** sutil (SVG fractalNoise, opacity 0.04, multiply). **Sin imágenes fotográficas** en las superficies core — el peso visual lo cargan la tipografía y la geometría.
- **Motivos de marca:** **Isotipo Umbral** (chevron descendente sobre la línea de umbral = el paso que se cruza, el revés y el descenso); **Wordmark EnVés** en Marcellus con color por letra; **Flor de la Vida** (7 círculos, rota 120s, casi imperceptible); **Vésica Piscis** (dos círculos intersectados = la rendija/portal, se traza al cargar); **Polvo dorado** (15 puntos flotando 8–13s); **Ornamentos** art déco entre secciones; **Cubo isométrico** (manifiesto = orden/decreto). *El antiguo isotipo de la puerta (8 marcos anidados + mirilla/rombo/cerradura) queda como motivo geométrico legacy del producto `escalera` — no es el isotipo de marca.*
- **Uso del isotipo (Umbral):** el sello es **marca de agua y cierre, nunca logo de header** (el header lleva el wordmark tipográfico). Vive grande y en silencio: hero, portada de email, cierre de página, favicon. Como **watermark** se usa al **4–6% de opacidad** detrás de secciones profundas, alineado con la capa de ruido de papel. **Un solo material** — oro champagne sobre oscuro, cocoa/tinta sobre claro. Legible a 32 px. Respeta `prefers-reduced-motion`.
- **Animación:** lenta y contemplativa. Easing global `cubic-bezier(0.25,0.46,0.45,0.94)`. Fades con leve translateY al revelar (scroll reveal 0.7s). Rotaciones perpetuas larguísimas (120s). Sin bounces, sin nada brusco. `prefers-reduced-motion` respetado.
- **Hover:** nav links → color cocoa/oro + filete de oro que crece desde el centro. Botones primarios → **barra de oro que entra por detrás del texto** mientras el texto pasa a negro. Theme switcher → rota −15°. Transiciones 0.3–0.4s.
- **Press:** no hay efecto de "shrink"; la marca prefiere el cambio de color al de escala.
- **Bordes y esquinas:** la web editorial usa **esquinas rectas (radius 0)** — botones, CTAs, secciones. Los radios suaves (8–12px) se reservan a **UI utilitaria**: burbujas de chat, inputs, avatares (círculo). Filetes de oro (1px) con opacidad 0.18 (sutil) o 0.5 (visible) como recurso decorativo central.
- **Sombras:** casi ausentes. La única sombra del sistema es el `drop-shadow` dorado del monograma masivo en el hero (`0 20px 60px rgba(196,162,101,.15)`) y la sombra de elevación del contenedor de chat. No hay sistema de elevación tipo Material.
- **Transparencia y blur:** header y overlays usan `backdrop-filter: blur(14–20px)` sobre fondo translúcido (cosmos/papel al 88–96%). 
- **Imágenes:** cuando se usan (avatares de la academia), son cálidas; el sistema core es prácticamente sin foto.
- **Layout:** header fijo con blur; secciones a 5rem (móvil) / 7.5rem (desktop) de padding vertical; contenedor de lectura ~1100px, narrow ~760px; composiciones asimétricas (hero 1.2fr / 1fr). Barra de progreso de scroll de 2px en oro.

---

## ICONOGRAPHY

Envés **no usa una librería de iconos** ni icon-font. El vocabulario es deliberadamente mínimo:

- **Caracteres Unicode como iconos:** flecha `→` (`\2192`, en Cormorant) para viñetas afirmativas y la flecha de "seguir"; `×` (`\00D7`) para viñetas de exclusión. El theme switcher usa `☾` / `✦`.
- **SVG inline puntuales:** el ícono de "enviar" del chat (avión de papel, stroke 2, currentColor), la hamburguesa del menú móvil (dos barras que rotan a X). Hay un único `ArrowNarrowRightIcon` como componente en el repo.
- **Geometría como icono:** los motivos (chevron Umbral, flor de la vida, vésica, cubo, ornamentos) cumplen el rol icónico/decorativo. Se construyen con SVG geométrico, nunca ilustración.
- **Set de los tres umbrales (legacy `escalera`):** los tres glifos **mirilla** (círculo + punto) = **Umbral I**, *observas*; **rombo** de oro sólido = **Umbral II**, *decides*; **cerradura** = **Protocolo**, *entras* — mapean la *Escalera de umbrales* y se usan **solo dentro del producto `escalera`** (pasos, estados, navegación de la escalera), trazo fino (1–1.8px) en oro o cocoa. Heredan del antiguo isotipo de la puerta; no se amplían a una librería ni se usan como iconografía general del sistema.
- **Emoji:** **nunca.**
- **Logos / sellos** (en `assets/`): la **identidad definitiva** es el **isotipo Umbral** (chevron descendente sobre la línea de umbral) + el **wordmark en Marcellus** policromo. `isotipo.svg` (chevron Umbral, 1024²), `isotipo-cuadrado-1080.svg` (avatares sociales), `isotipo-monocromo.svg` (marfil), `favicon-isotipo.svg` (32px), `enves-favicon.svg` (64px), `sigil-umbral*.svg` (solo el sigilo, claro/oscuro), `logo-umbral-*.svg` (lockups completos claro/oscuro + horizontales), `enves-logo-dark/light.svg` y `wordmark-oro/cocoa.svg` (Marcellus), `lockup-horizontal/vertical.svg`. Spec completa en `Logo Envés.html`. *La “puerta” (8 marcos anidados) queda como motivo geométrico legacy del producto `escalera`, no como isotipo.*

> Si necesitas un icono que no existe en este vocabulario, prefiere un SVG geométrico de trazo fino (1–2px) en oro o cocoa, alineado con los ornamentos — no introduzcas una librería de terceros ni emoji.

---

## Índice / manifiesto del repositorio

**Raíz**
- `styles.css` — punto de entrada global (solo `@import`s). Enlaza este archivo.
- `tokens/` — `colors.css` (paleta + alias semánticos + color por letra), `typography.css` (4 familias + escala fluida + tracking), `spacing.css` (espaciado, radios, easing, z-index).
- `readme.md` — este archivo.
- `SKILL.md` — manifiesto compatible con Agent Skills.

**Assets** (`assets/`)
- Logos/isotipos/wordmarks oficiales (ver ICONOGRAPHY).
- *Kit de Substack* (artefacto entregado aparte): `logo-e.svg`, `cover.svg`, `email-banner*.svg`, `post-preview.svg`, `sigil-umbral*.svg` + PNGs en `assets/png/`. Usa la identidad definitiva: avatar = sigilo Umbral, wordmark en Marcellus policromo.

**Foundations** (`guidelines/`) — tarjetas specimen para la pestaña Design System: colores (negros, oro, cocoa, cremas), tipografía (display, italic, body, labels), spacing (escala, radios, líneas), brand (isotipo, variantes, wordmark, lockup, geometría, ornamentos).

**Componentes** (`components/`)
- `core/` — `Button`/`ButtonLink`, `Eyebrow`, `Heading`.
- `brand/` — `MonogramaEnves`, `OrnamentoSection`.

**UI Kits** (`ui_kits/`)
- `website/` — homepage de enves.io (hero, posicionamiento, dimensiones, filtro, espejo CTA, footer). Con theme toggle.
- `espejo/` — chatbot Espejo de Precisión (gate de email → chat interactivo con respuestas simuladas).
- `escalera/` — La Escalera de umbrales (Umbral I → II → Protocolo). Conserva el **motivo legacy de la puerta**: figura que se abre al cargar, watermark al 5%, y los tres glifos (mirilla/rombo/cerradura) como iconografía propia del producto. No usa el isotipo de marca (Umbral).lla/rombo/cerradura) como nodos de progresión sobre filete de oro; sección de negación en crema.

**Artefactos sueltos en raíz**: `Logo Envés.html` (spec de identidad definitiva — isotipo Umbral + Marcellus), `Envés Substack Kit.html`, `Estudio de Color.html`.

---

## CAVEATS

- **Fuentes:** Cormorant Garamond, EB Garamond, Familjen Grotesk e Inter se cargan desde **Google Fonts** vía `@import`. Son las fuentes reales del producto (cargadas con `next/font/google` en el repo), así que no hay sustitución — pero si quieres self-hostear los binarios para producción, reemplaza el `@import` de `tokens/typography.css` por `@font-face` locales.
- Los componentes React se sirven vía el bundle generado (`_ds_bundle.js`); las tarjetas/kits que lo consumen funcionan una vez compilado.
